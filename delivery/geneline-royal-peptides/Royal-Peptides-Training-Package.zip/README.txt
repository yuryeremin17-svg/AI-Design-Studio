═══════════════════════════════════════════════════════════
  ROYAL PEPTIDES BY GENELINE
  Обучающий курс для дистрибьюторской сети
  Версия 1.2 · 2026
═══════════════════════════════════════════════════════════

ЧТО ВНУТРИ / WHAT'S INSIDE
──────────────────────────────────────────────────────────
1. Royal-Peptides-by-Geneline-Training.pdf
   Главный файл для рассылки. 36 страниц, 1600×900.
   Main file for distribution. 36 pages, 1600×900.

2. Interactive/Presentation.html
   Интерактивная версия для просмотра в браузере.
   Interactive HTML for browser (projector, portal, laptop).

3. Slides-PNG/
   36 отдельных слайдов в формате PNG.
   36 individual slides as PNG (for messengers and social).

4. README.txt — этот файл / this file

ЧТО ОБНОВЛЕНО В ВЕРСИИ 1.2 / WHAT'S NEW IN v1.2
──────────────────────────────────────────────────────────
• Крупный шрифт +20% для лучшей читаемости (врачи 40+)
  Larger font +20% for better readability (doctors 40+)

• Премиум-иллюстрации в фирстиле Geneline:
  Premium illustrations in Geneline brand style:
  — Механизм пептидов: ДНК → ножницы → пептид-ключ → клетка
  — НОВЫЙ слайд «Принцип ключ → замок»
  — STOPBACTERIA: иллюстрация мембраны с бактериями

• Все 10 комплексов с иконками-метафорами в hero-блоках
  All 10 complexes with metaphor icons in hero blocks

СОДЕРЖАНИЕ / TABLE OF CONTENTS (36 slides)
──────────────────────────────────────────────────────────
  Обложка + Структура + Дисклеймер (3)
  МОДУЛЬ 01. Основы пептидной терапии (5):
    Что такое пептиды (большая иллюстрация механизма)
    Что регулируют пептиды (5 пиктограмм систем)
    Принцип «ключ → замок» (НОВЫЙ слайд)
    Пептиды vs препараты vs гормоны (таблица)
  МОДУЛЬ 02. Как выбрать комплекс (3):
    Таблица быстрого выбора + Карта на силуэте человека
  МОДУЛЬ 03. 10 комплексов (11):
    AMORE · ACTIVEBRAIN · IMMUNACTIV · NO STRESS · OXYGEN
    RECOVERY · RELIEF · STOPBACTERIA · STRESSRELIEF · TESTOBOOSTER
  МОДУЛЬ 04. Алгоритмы работы (4):
    Алгоритм визита (8 шагов) · Красные флаги · Контрольная точка
  МОДУЛЬ 05. Продажи и коммуникация (4):
    Формулировки · 5 возражений · Юридические риски
  МОДУЛЬ 06. Учебные кейсы (3):
    4 типовых случая
  FAQ + Чек-лист специалиста + Финал (3)

КАК ИСПОЛЬЗОВАТЬ / HOW TO USE
──────────────────────────────────────────────────────────
• Индивидуальная рассылка → PDF
  Individual distribution → PDF
• Групповое обучение → Presentation.html (F11 = fullscreen)
  Group training → Open Presentation.html, press F11
• Соцсети / мессенджеры → отдельные PNG из Slides-PNG/
  Social / messengers → use individual PNGs

ОБРАТНАЯ СВЯЗЬ / CONTACTS
──────────────────────────────────────────────────────────
Geneline — Ваша лучшая генетическая линия
Geneline — Your best genetic line

Тел / Phone:      +7 (916) 568-27-01
Telegram / IG:    @geneline.clinic
Сайт / Web:       geneline.clinic

═══════════════════════════════════════════════════════════
  Дизайн-команда AI Design Studio · 2026
  AI Design Studio · 2026
═══════════════════════════════════════════════════════════
